package com.example.demo.member.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.demo.member.dto.MemberDTO;
import com.example.demo.member.entity.Member;
import com.example.demo.member.repository.MemberRepository;

public class MemberServiceImpl implements MemberService{

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Member member = MemberRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        return User.builder()
                .username(member.getUsername())
                .password(member.getPassword())
                .roles(member.getRole())
                .build();
	}

	@Override
	public MemberDTO registerMember(MemberDTO memberDTO) {
		// TODO Auto-generated method stub
		return null;
	}

}
